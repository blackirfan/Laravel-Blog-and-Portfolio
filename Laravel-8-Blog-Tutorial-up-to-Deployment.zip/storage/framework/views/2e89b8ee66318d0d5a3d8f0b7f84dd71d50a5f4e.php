<?php $__env->startSection('main'); ?>
    <!-- main -->
    <main class="container">
      <section class="single-blog-post">
        <h1><?php echo e($post->title); ?></h1>

        <p class="time-and-author">
          <?php echo e($post->created_at->diffForHumans()); ?>

          <span>Written By <?php echo e($post->user->name); ?></span>
        </p>
        <!-- <div class="single-blog-post-ContentImage" data-aos="fade-left">
          <img src="<?php echo e(asset($post->imagePath)); ?>" alt="" />
        </div> -->

        <div class="about-text">
         <?php echo $post->body; ?>

        </div>
      </section>
      <section class="recommended">
        <p>Related</p>
        <div class="recommended-cards">
        <?php $__currentLoopData = $relatedPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relatedPost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="">
          <div class="recommended-card">
            <img src="<?php echo e(asset($relatedPost->imagePath)); ?>" alt="" loading="lazy" />
            <h4>
              <?php echo e($relatedPost->title); ?>

            </h4>
          </div>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </section>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel-8-Blog-Tutorial-up-to-Deployment\resources\views/blogPosts/single-blog-post.blade.php ENDPATH**/ ?>