
<?php $__env->startSection('main'); ?>
    <main class="container" style="background-color: #fff;">
        <section id="contact-us">
            <h1 style="padding-top: 50px;">Create New Educations</h1>
            <?php echo $__env->make('includes.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Contact Form -->
            <div class="contact-form">
                <form action="<?php echo e(route('educations.store')); ?>" method="post" enctype="form-data">
                    <?php echo csrf_field(); ?>
                    <!-- institutionname -->
                    <label for="institutionname"><span>Institution Name</span></label>
                    <input type="text" id="institutionname" name="institutionname" value="<?php echo e(old('institutionname')); ?>" />
                    <?php $__errorArgs = ['institutionname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        
                        <p style="color: red; margin-bottom:25px;"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <!-- address -->
                    <label for="address"><span>Address</span></label>
                    <input type="text" id="address" name="address" value="<?php echo e(old('address')); ?>" />
                    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        
                        <p style="color: red; margin-bottom:25px;"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <!-- institutiontype -->
                    <label for="institutiontype"><span>Institution Type</span></label>
                    <input type="text" id="institutiontype" name="institutiontype" value="<?php echo e(old('institutiontype')); ?>" />
                    <?php $__errorArgs = ['institutiontype'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        
                        <p style="color: red; margin-bottom:25px;"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <!-- certificatetype -->
                    <label for="github"><span>Certificate Type</span></label>
                    <input type="text" id="certificatetype" name="certificatetype" value="<?php echo e(old('certificatetype')); ?>" />
                    <?php $__errorArgs = ['certificatetype'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        
                        <p style="color: red; margin-bottom:25px;"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <!-- grade -->
                    <label for="grade"><span>Grade</span></label>
                    <input type="text" id="grade" name="grade" value="<?php echo e(old('grade')); ?>" />
                    <?php $__errorArgs = ['grade'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        
                        <p style="color: red; margin-bottom:25px;"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <!-- Button -->
                    <input type="submit" value="Submit" />
                </form>
            </div>

        </section>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel-8-Blog-Tutorial-up-to-Deployment\resources\views/educations/create-educations.blade.php ENDPATH**/ ?>