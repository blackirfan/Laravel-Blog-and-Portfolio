

<?php $__env->startSection('main'); ?>
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    You're logged in! from profile update

                    <div class="dashboard">
                        <ul>
                            <li><a href="<?php echo e(route('userDetails.create')); ?>">Create User Details</a></li>
                            <li><a href="<?php echo e(route('userDetails.edit')); ?>">Update User Details</a></li>
                            <li><a href="<?php echo e(route('educations.create')); ?>">Create Educations</a></li>
                            <li><a href="<?php echo e(route('educations.list')); ?>">List Educations</a></li>
                            <li><a href="<?php echo e(route('publicationDetails.create')); ?>">Create Publication Details</a></li>
                            <!-- <li><a href="<?php echo e(route('categories.create')); ?>">Create Category</a></li>
                            <li><a href="<?php echo e(route('categories.index')); ?>">Categories List</a></li> -->
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel-8-Blog-Tutorial-up-to-Deployment\resources\views/profile_update.blade.php ENDPATH**/ ?>