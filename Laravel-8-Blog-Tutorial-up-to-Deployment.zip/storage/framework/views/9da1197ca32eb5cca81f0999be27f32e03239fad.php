<!-- <h1><?php echo e($educations); ?></h1> -->
<style>

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: "Inter", sans-serif;
  color: #343a40;
  line-height: 1;
  display: flex;
  justify-content: center;
}

table {
  width: 800px;
  margin-top: 80px;
  /* border: 1px solid #343a40; */
  border-collapse: collapse;
  font-size: 18px;
}

th,
td {
  /* border: 1px solid #343a40; */
  padding: 16px 24px;
  text-align: left;
}

thead th {
  background-color: #087f5b;
  color: #fff;
  width: 25%;
}

tbody tr:nth-child(even) {
  background-color: #f8f9fa;
}

tbody tr:nth-child(odd) {
  background-color: #e9ecef;
}
</style>
<div class="card">

<table>
    <thead>
      <tr>
        <th> ID </th>
        <th> Institution Name</th>
        <th> Institution Type</th>
        <th> Action</th>
      </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($education->id ?? ''); ?></td>
        <td><?php echo e($education->institutionname?? ''); ?></td>
        <td> <?php echo e($education->institutiontype?? ''); ?></td>
        <td>--</td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>
<?php /**PATH C:\xampp\htdocs\Laravel-8-Blog-Tutorial-up-to-Deployment\resources\views/educations/list-educations.blade.php ENDPATH**/ ?>