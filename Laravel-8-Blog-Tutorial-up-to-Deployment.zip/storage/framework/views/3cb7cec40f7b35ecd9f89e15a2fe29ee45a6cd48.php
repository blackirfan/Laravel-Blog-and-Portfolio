<?php $__env->startSection('header'); ?>
    <!-- header -->
    <!-- <header class="header" style=" background-image: url(<?php echo e(asset("images/photography.jpg")); ?>);"> -->
    <header class="header" style=" background-image: url(<?php echo e(asset("https://cdn.pixabay.com/photo/2017/08/01/00/01/map-2562138_960_720.jpg")); ?>);">
      <div class="header-text">
        <h1>Irfan Hossain Blog</h1>
        <h4>Dashboard of interested topics...</h4>
      </div>
      <div class="overlay"></div>
    </header>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <!-- main -->
    <main class="container">
      <h2 class="header-title">Latest Blog Posts</h2>
      <section class="cards-blog latest-blog">
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card-blog-content">
         <img src="<?php echo e(asset($post->imagePath)); ?>" alt="" />
         <p>
           <?php echo e($post->created_at->diffForHumans()); ?>

           <span>Written By <?php echo e($post->user->name); ?></span>
         </p>
         <h4>
           <a href="<?php echo e(route('blog.show', $post)); ?>"><?php echo e($post->title); ?></a>
         </h4>
       </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </section>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel-8-Blog-Tutorial-up-to-Deployment\resources\views/welcome.blade.php ENDPATH**/ ?>